// JavaScript Document
alert("JavaScript  in external js file!");
document.write("Là lá la la vui quá là vui");